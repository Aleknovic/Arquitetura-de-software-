import { getDb } from "./db";
import type { Produto, ProdutoInput, Categoria } from "@/types";

export function listarProdutos(): Produto[] {
  const db = getDb();
  return db
    .prepare(
      `SELECT p.*, c.nome AS categoria_nome
       FROM produtos p
       LEFT JOIN categorias c ON c.id = p.categoria_id
       ORDER BY p.criado_em DESC`
    )
    .all() as Produto[];
}

export function buscarProduto(id: number): Produto | null {
  const db = getDb();
  const row = db
    .prepare(
      `SELECT p.*, c.nome AS categoria_nome
       FROM produtos p
       LEFT JOIN categorias c ON c.id = p.categoria_id
       WHERE p.id = ?`
    )
    .get(id);
  return (row as Produto) ?? null;
}

export function criarProduto(dados: ProdutoInput): Produto {
  const db = getDb();
  const resultado = db
    .prepare(
      `INSERT INTO produtos (nome, descricao, preco, estoque, categoria_id)
       VALUES (@nome, @descricao, @preco, @estoque, @categoria_id)`
    )
    .run({
      nome: dados.nome,
      descricao: dados.descricao ?? null,
      preco: dados.preco,
      estoque: dados.estoque,
      categoria_id: dados.categoria_id ?? null,
    });

  return buscarProduto(resultado.lastInsertRowid as number)!;
}

export function atualizarProduto(
  id: number,
  dados: Partial<ProdutoInput>
): Produto | null {
  const db = getDb();
  const atual = buscarProduto(id);
  if (!atual) return null;

  db.prepare(
    `UPDATE produtos
     SET nome         = @nome,
         descricao    = @descricao,
         preco        = @preco,
         estoque      = @estoque,
         categoria_id = @categoria_id,
         atualizado_em = datetime('now','localtime')
     WHERE id = @id`
  ).run({
    id,
    nome: dados.nome ?? atual.nome,
    descricao: dados.descricao !== undefined ? dados.descricao : atual.descricao,
    preco: dados.preco ?? atual.preco,
    estoque: dados.estoque ?? atual.estoque,
    categoria_id:
      dados.categoria_id !== undefined
        ? dados.categoria_id
        : atual.categoria_id,
  });

  return buscarProduto(id);
}

export function removerProduto(id: number): boolean {
  const db = getDb();
  const resultado = db
    .prepare("DELETE FROM produtos WHERE id = ?")
    .run(id);
  return resultado.changes > 0;
}

export function listarCategorias(): Categoria[] {
  const db = getDb();
  return db
    .prepare("SELECT * FROM categorias ORDER BY nome")
    .all() as Categoria[];
}
