import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

// Garante que o diretório data existe
const dataDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const DB_PATH = path.join(dataDir, "produtos.db");

// Singleton: reutiliza a mesma conexão durante toda a vida do processo
let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma("journal_mode = WAL"); // melhor performance em leituras simultâneas
    inicializarBanco(db);
  }
  return db;
}

function inicializarBanco(db: Database.Database) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS categorias (
      id   INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT    NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS produtos (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      nome        TEXT    NOT NULL,
      descricao   TEXT,
      preco       REAL    NOT NULL,
      estoque     INTEGER NOT NULL DEFAULT 0,
      categoria_id INTEGER REFERENCES categorias(id),
      criado_em   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
      atualizado_em TEXT  NOT NULL DEFAULT (datetime('now','localtime'))
    );

    -- Seed de categorias
    INSERT OR IGNORE INTO categorias (nome) VALUES
      ('Eletrônicos'),
      ('Vestuário'),
      ('Alimentos'),
      ('Móveis'),
      ('Livros'),
      ('Esportes');

    -- Seed de produtos de exemplo
    INSERT OR IGNORE INTO produtos (id, nome, descricao, preco, estoque, categoria_id) VALUES
      (1, 'Notebook Gamer', 'Intel i7, 16GB RAM, RTX 3060, SSD 512GB', 5499.90, 8,  1),
      (2, 'Camiseta Polo', 'Algodão premium, disponível em várias cores', 89.90,  42, 2),
      (3, 'Whey Protein 1kg', 'Sabor chocolate, 24g proteína por dose', 159.90, 15, 3),
      (4, 'Mesa de Escritório', 'MDF 18mm, 140x60cm, cor branca', 399.00, 5,  4),
      (5, 'Clean Code', 'Robert C. Martin - Habilidades práticas do Agile Software', 79.90,  20, 5);
  `);
}
