import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Necessário para better-sqlite3 (módulo nativo Node.js)
  serverExternalPackages: ["better-sqlite3"],
};

export default nextConfig;
