export interface Categoria {
  id: number;
  nome: string;
}

export interface Produto {
  id: number;
  nome: string;
  descricao: string | null;
  preco: number;
  estoque: number;
  categoria_id: number | null;
  categoria_nome?: string;
  criado_em: string;
  atualizado_em: string;
}

export interface ProdutoInput {
  nome: string;
  descricao?: string;
  preco: number;
  estoque: number;
  categoria_id?: number | null;
}
