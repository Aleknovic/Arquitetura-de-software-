import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Estoque — Cadastro de Produtos",
  description: "Sistema de cadastro de produtos com Next.js + SQLite + SSR",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Serif+Display&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        {/* ─── Navbar ─────────────────────────────────────────── */}
        <nav
          style={{
            background: "var(--color-surface-2)",
            borderBottom: "1px solid var(--color-border)",
            position: "sticky",
            top: 0,
            zIndex: 50,
          }}
        >
          <div
            style={{
              maxWidth: 1100,
              margin: "0 auto",
              padding: "0 1.5rem",
              height: 60,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Link href="/" style={{ textDecoration: "none" }}>
              <span
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "1.35rem",
                  color: "var(--color-text)",
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                }}
              >
                <span style={{ color: "var(--color-brand-500)" }}>▸</span>
                Estoque
              </span>
            </Link>

            <div style={{ display: "flex", gap: "0.5rem" }}>
              <Link href="/produtos" style={{ textDecoration: "none" }}>
                <button className="btn-ghost" style={{ fontSize: "0.875rem" }}>
                  Produtos
                </button>
              </Link>
              <Link href="/produtos/novo" style={{ textDecoration: "none" }}>
                <button className="btn-primary" style={{ fontSize: "0.875rem" }}>
                  + Novo Produto
                </button>
              </Link>
            </div>
          </div>
        </nav>

        {/* ─── Conteúdo ─────────────────────────────────────── */}
        <main
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            padding: "2rem 1.5rem",
          }}
        >
          {children}
        </main>

        {/* ─── Footer ───────────────────────────────────────── */}
        <footer
          style={{
            borderTop: "1px solid var(--color-border)",
            padding: "1.5rem",
            textAlign: "center",
            fontSize: "0.75rem",
            color: "var(--color-muted)",
            marginTop: "4rem",
          }}
        >
          Next.js · App Router · SQLite · SSR &nbsp;|&nbsp; Projeto acadêmico
        </footer>
      </body>
    </html>
  );
}
