import Link from "next/link";
import { listarCategorias } from "@/lib/produtos";
import FormProduto from "../FormProduto";

export const metadata = { title: "Novo Produto | Estoque" };

export default function NovoProdutoPage() {
  const categorias = listarCategorias();

  return (
    <div style={{ maxWidth: 600 }}>
      {/* Breadcrumb */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.4rem",
          fontSize: "0.8rem",
          color: "var(--color-muted)",
          marginBottom: "1.5rem",
        }}
      >
        <Link href="/produtos" style={{ color: "var(--color-muted)", textDecoration: "none" }}>
          Produtos
        </Link>
        <span>/</span>
        <span style={{ color: "var(--color-text)" }}>Novo</span>
      </div>

      <h1 style={{ margin: "0 0 0.25rem", fontSize: "2rem" }}>Novo Produto</h1>
      <p style={{ color: "var(--color-muted)", margin: "0 0 2rem", fontSize: "0.875rem" }}>
        Preencha os campos abaixo para cadastrar um novo produto.
      </p>

      <FormProduto categorias={categorias} modo="criar" />
    </div>
  );
}
