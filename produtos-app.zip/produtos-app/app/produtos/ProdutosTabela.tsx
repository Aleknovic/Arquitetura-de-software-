"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { Produto } from "@/types";

interface Props {
  produtos: Produto[];
}

export default function ProdutosTabela({ produtos: inicial }: Props) {
  const [busca, setBusca] = useState("");
  const [removendo, setRemovendo] = useState<number | null>(null);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const filtrados = inicial.filter(
    (p) =>
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      (p.categoria_nome ?? "").toLowerCase().includes(busca.toLowerCase()) ||
      (p.descricao ?? "").toLowerCase().includes(busca.toLowerCase())
  );

  async function handleRemover(id: number, nome: string) {
    if (!confirm(`Remover "${nome}"? Esta ação não pode ser desfeita.`)) return;

    setRemovendo(id);
    try {
      const res = await fetch(`/api/produtos/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      startTransition(() => router.refresh());
    } catch {
      alert("Erro ao remover produto.");
    } finally {
      setRemovendo(null);
    }
  }

  return (
    <div>
      {/* Campo de busca */}
      <div style={{ marginBottom: "1.25rem" }}>
        <input
          className="input"
          placeholder="🔍  Buscar por nome, categoria ou descrição..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          style={{ maxWidth: 420 }}
        />
      </div>

      {filtrados.length === 0 ? (
        <div
          className="card"
          style={{
            padding: "3rem",
            textAlign: "center",
            color: "var(--color-muted)",
          }}
        >
          {busca ? (
            <>
              <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>🔍</div>
              Nenhum produto encontrado para &quot;<strong>{busca}</strong>&quot;
            </>
          ) : (
            <>
              <div style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>📦</div>
              Nenhum produto cadastrado ainda.{" "}
              <Link href="/produtos/novo" style={{ color: "var(--color-brand-400)" }}>
                Cadastre o primeiro
              </Link>
              .
            </>
          )}
        </div>
      ) : (
        <div className="card" style={{ overflow: "hidden" }}>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              fontSize: "0.875rem",
            }}
          >
            <thead>
              <tr
                style={{
                  background: "var(--color-surface-3)",
                  borderBottom: "1px solid var(--color-border)",
                }}
              >
                {["ID", "Nome", "Categoria", "Preço", "Estoque", "Ações"].map(
                  (h) => (
                    <th
                      key={h}
                      style={{
                        padding: "0.75rem 1rem",
                        textAlign: h === "Ações" || h === "Preço" || h === "Estoque" ? "right" : "left",
                        fontSize: "0.72rem",
                        fontWeight: 700,
                        color: "var(--color-muted)",
                        textTransform: "uppercase",
                        letterSpacing: "0.07em",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {h}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filtrados.map((produto, i) => (
                <tr
                  key={produto.id}
                  style={{
                    borderBottom:
                      i < filtrados.length - 1
                        ? "1px solid var(--color-border)"
                        : "none",
                    opacity: removendo === produto.id || isPending ? 0.5 : 1,
                    transition: "opacity 0.2s",
                  }}
                >
                  <td
                    style={{
                      padding: "0.875rem 1rem",
                      fontFamily: "var(--font-mono)",
                      fontSize: "0.78rem",
                      color: "var(--color-muted)",
                    }}
                  >
                    #{produto.id}
                  </td>

                  <td style={{ padding: "0.875rem 1rem" }}>
                    <Link
                      href={`/produtos/${produto.id}`}
                      style={{
                        color: "var(--color-text)",
                        textDecoration: "none",
                        fontWeight: 600,
                      }}
                    >
                      {produto.nome}
                    </Link>
                    {produto.descricao && (
                      <div
                        style={{
                          fontSize: "0.78rem",
                          color: "var(--color-muted)",
                          marginTop: "0.15rem",
                          maxWidth: 260,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {produto.descricao}
                      </div>
                    )}
                  </td>

                  <td style={{ padding: "0.875rem 1rem" }}>
                    {produto.categoria_nome ? (
                      <span className="badge">{produto.categoria_nome}</span>
                    ) : (
                      <span style={{ color: "var(--color-muted)", fontSize: "0.8rem" }}>—</span>
                    )}
                  </td>

                  <td
                    style={{
                      padding: "0.875rem 1rem",
                      textAlign: "right",
                      fontFamily: "var(--font-mono)",
                      fontWeight: 600,
                      color: "var(--color-brand-400)",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {produto.preco.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })}
                  </td>

                  <td
                    style={{
                      padding: "0.875rem 1rem",
                      textAlign: "right",
                      fontFamily: "var(--font-mono)",
                    }}
                  >
                    <span
                      style={{
                        color:
                          produto.estoque === 0
                            ? "#f87171"
                            : produto.estoque < 5
                            ? "#fbbf24"
                            : "var(--color-text)",
                      }}
                    >
                      {produto.estoque}
                    </span>
                  </td>

                  <td style={{ padding: "0.875rem 1rem", textAlign: "right" }}>
                    <div
                      style={{ display: "flex", gap: "0.5rem", justifyContent: "flex-end" }}
                    >
                      <Link href={`/produtos/${produto.id}`}>
                        <button
                          className="btn-ghost"
                          style={{ padding: "0.3rem 0.6rem", fontSize: "0.78rem" }}
                          title="Ver detalhes"
                        >
                          👁
                        </button>
                      </Link>
                      <Link href={`/produtos/${produto.id}/editar`}>
                        <button
                          className="btn-ghost"
                          style={{ padding: "0.3rem 0.6rem", fontSize: "0.78rem" }}
                          title="Editar"
                        >
                          ✏️
                        </button>
                      </Link>
                      <button
                        className="btn-ghost"
                        style={{
                          padding: "0.3rem 0.6rem",
                          fontSize: "0.78rem",
                          borderColor: "#7f1d1d",
                          color: "#f87171",
                        }}
                        title="Remover"
                        disabled={removendo === produto.id}
                        onClick={() => handleRemover(produto.id, produto.nome)}
                      >
                        🗑
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p
        style={{
          marginTop: "0.75rem",
          fontSize: "0.75rem",
          color: "var(--color-muted)",
        }}
      >
        Exibindo {filtrados.length} de {inicial.length} produto{inicial.length !== 1 ? "s" : ""}
      </p>
    </div>
  );
}
