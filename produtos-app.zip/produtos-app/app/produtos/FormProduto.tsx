"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Produto, Categoria } from "@/types";

interface Props {
  categorias: Categoria[];
  produto?: Produto;
  modo: "criar" | "editar";
}

export default function FormProduto({ categorias, produto, modo }: Props) {
  const router = useRouter();
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  const [form, setForm] = useState({
    nome:         produto?.nome        ?? "",
    descricao:    produto?.descricao   ?? "",
    preco:        produto?.preco       ?? "",
    estoque:      produto?.estoque     ?? 0,
    categoria_id: produto?.categoria_id ?? "",
  });

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro(null);
    setEnviando(true);

    const payload = {
      nome:        form.nome.trim(),
      descricao:   form.descricao.trim() || undefined,
      preco:       Number(form.preco),
      estoque:     Number(form.estoque),
      categoria_id: form.categoria_id ? Number(form.categoria_id) : null,
    };

    try {
      const url    = modo === "criar" ? "/api/produtos" : `/api/produtos/${produto!.id}`;
      const method = modo === "criar" ? "POST" : "PUT";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setErro(data.erro ?? "Erro desconhecido");
        return;
      }

      router.push(`/produtos/${data.id}`);
      router.refresh();
    } catch {
      setErro("Erro de conexão. Tente novamente.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="card" style={{ padding: "2rem" }}>
        <div style={{ display: "grid", gap: "1.25rem" }}>

          {/* Nome */}
          <div>
            <label htmlFor="nome">Nome *</label>
            <input
              id="nome"
              name="nome"
              className="input"
              required
              placeholder="Ex: Notebook Gamer"
              value={form.nome}
              onChange={handleChange}
              style={{ marginTop: "0.4rem" }}
            />
          </div>

          {/* Descrição */}
          <div>
            <label htmlFor="descricao">Descrição</label>
            <textarea
              id="descricao"
              name="descricao"
              className="input"
              placeholder="Detalhes do produto (opcional)"
              value={form.descricao}
              onChange={handleChange}
              rows={3}
              style={{ marginTop: "0.4rem", resize: "vertical" }}
            />
          </div>

          {/* Preço + Estoque lado a lado */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
            <div>
              <label htmlFor="preco">Preço (R$) *</label>
              <input
                id="preco"
                name="preco"
                type="number"
                min="0"
                step="0.01"
                required
                className="input"
                placeholder="0,00"
                value={form.preco}
                onChange={handleChange}
                style={{ marginTop: "0.4rem" }}
              />
            </div>
            <div>
              <label htmlFor="estoque">Estoque *</label>
              <input
                id="estoque"
                name="estoque"
                type="number"
                min="0"
                required
                className="input"
                placeholder="0"
                value={form.estoque}
                onChange={handleChange}
                style={{ marginTop: "0.4rem" }}
              />
            </div>
          </div>

          {/* Categoria */}
          <div>
            <label htmlFor="categoria_id">Categoria</label>
            <select
              id="categoria_id"
              name="categoria_id"
              className="input"
              value={form.categoria_id}
              onChange={handleChange}
              style={{ marginTop: "0.4rem" }}
            >
              <option value="">— Sem categoria —</option>
              {categorias.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Erro */}
        {erro && (
          <div
            style={{
              marginTop: "1rem",
              padding: "0.75rem 1rem",
              background: "rgba(248,113,113,0.1)",
              border: "1px solid #7f1d1d",
              borderRadius: 8,
              color: "#f87171",
              fontSize: "0.875rem",
            }}
          >
            ⚠️ {erro}
          </div>
        )}
      </div>

      {/* Botões */}
      <div style={{ display: "flex", gap: "0.75rem", marginTop: "1.25rem" }}>
        <button
          type="submit"
          className="btn-primary"
          disabled={enviando}
          style={{ minWidth: 140 }}
        >
          {enviando
            ? "Salvando…"
            : modo === "criar"
            ? "Cadastrar Produto"
            : "Salvar Alterações"}
        </button>
        <button
          type="button"
          className="btn-ghost"
          onClick={() => router.back()}
          disabled={enviando}
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
