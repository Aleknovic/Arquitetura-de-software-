/**
 * /produtos — Listagem de Produtos
 *
 * 🔑 SSR em ação:
 * Este é um React Server Component. O Next.js executa esta função
 * diretamente no servidor Node.js, lê o SQLite e envia o HTML
 * completo (com a tabela preenchida) para o navegador.
 * O cliente NÃO precisa fazer nenhum fetch adicional.
 */

import Link from "next/link";
import { listarProdutos } from "@/lib/produtos";
import ProdutosTabela from "./ProdutosTabela";

// force-dynamic garante que a página nunca seja cacheada estaticamente
// (dados sempre frescos do banco a cada request)
export const dynamic = "force-dynamic";

export const metadata = {
  title: "Produtos | Estoque",
};

export default function ProdutosPage() {
  // ✅ Leitura direta do banco — sem fetch, sem useEffect, sem loading state
  const produtos = listarProdutos();

  return (
    <div>
      {/* Cabeçalho */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: "1rem",
          marginBottom: "2rem",
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "0.5rem" }}>
            <span className="ssr-tag">
              <span>⚡</span> Renderizado no servidor
            </span>
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "0.72rem",
                color: "var(--color-muted)",
              }}
            >
              {produtos.length} produto{produtos.length !== 1 ? "s" : ""} encontrado{produtos.length !== 1 ? "s" : ""}
            </span>
          </div>
          <h1 style={{ margin: 0, fontSize: "2rem" }}>Produtos</h1>
          <p style={{ color: "var(--color-muted)", margin: "0.25rem 0 0", fontSize: "0.875rem" }}>
            HTML gerado no servidor antes de chegar ao navegador
          </p>
        </div>

        <Link href="/produtos/novo">
          <button className="btn-primary">+ Novo Produto</button>
        </Link>
      </div>

      {/* Tabela (Client Component para interatividade: busca + exclusão) */}
      <ProdutosTabela produtos={produtos} />
    </div>
  );
}
