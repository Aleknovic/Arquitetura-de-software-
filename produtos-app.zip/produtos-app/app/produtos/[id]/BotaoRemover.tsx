"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function BotaoRemover({ id, nome }: { id: number; nome: string }) {
  const [removendo, setRemovendo] = useState(false);
  const router = useRouter();

  async function handleRemover() {
    if (!confirm(`Remover "${nome}"? Esta ação não pode ser desfeita.`)) return;
    setRemovendo(true);
    try {
      const res = await fetch(`/api/produtos/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error();
      router.push("/produtos");
      router.refresh();
    } catch {
      alert("Erro ao remover produto.");
      setRemovendo(false);
    }
  }

  return (
    <button
      className="btn-ghost"
      style={{ borderColor: "#7f1d1d", color: "#f87171" }}
      onClick={handleRemover}
      disabled={removendo}
    >
      {removendo ? "Removendo…" : "🗑 Remover"}
    </button>
  );
}
