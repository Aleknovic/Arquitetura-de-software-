import { notFound } from "next/navigation";
import Link from "next/link";
import { buscarProduto, listarCategorias } from "@/lib/produtos";
import FormProduto from "../../FormProduto";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props) {
  const { id } = await params;
  const produto = buscarProduto(Number(id));
  return { title: produto ? `Editar: ${produto.nome} | Estoque` : "Não encontrado" };
}

export default async function EditarProdutoPage({ params }: Props) {
  const { id } = await params;
  const produto = buscarProduto(Number(id));
  if (!produto) notFound();

  const categorias = listarCategorias();

  return (
    <div style={{ maxWidth: 600 }}>
      {/* Breadcrumb */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.4rem",
          fontSize: "0.8rem",
          color: "var(--color-muted)",
          marginBottom: "1.5rem",
        }}
      >
        <Link href="/produtos" style={{ color: "var(--color-muted)", textDecoration: "none" }}>Produtos</Link>
        <span>/</span>
        <Link href={`/produtos/${produto.id}`} style={{ color: "var(--color-muted)", textDecoration: "none" }}>{produto.nome}</Link>
        <span>/</span>
        <span style={{ color: "var(--color-text)" }}>Editar</span>
      </div>

      <h1 style={{ margin: "0 0 0.25rem", fontSize: "2rem" }}>Editar Produto</h1>
      <p style={{ color: "var(--color-muted)", margin: "0 0 2rem", fontSize: "0.875rem" }}>
        Altere os campos desejados e salve.
      </p>

      <FormProduto
        categorias={categorias}
        produto={produto}
        modo="editar"
      />
    </div>
  );
}
