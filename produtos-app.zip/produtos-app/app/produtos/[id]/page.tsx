/**
 * /produtos/[id] — Detalhe do Produto
 *
 * Server Component: dados carregados no servidor via SQLite
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { buscarProduto } from "@/lib/produtos";
import BotaoRemover from "./BotaoRemover";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props) {
  const { id } = await params;
  const produto = buscarProduto(Number(id));
  return {
    title: produto ? `${produto.nome} | Estoque` : "Produto não encontrado",
  };
}

export default async function ProdutoPage({ params }: Props) {
  const { id } = await params;
  const produto = buscarProduto(Number(id));

  if (!produto) notFound();

  return (
    <div style={{ maxWidth: 700 }}>
      {/* Breadcrumb */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0.4rem",
          fontSize: "0.8rem",
          color: "var(--color-muted)",
          marginBottom: "1.5rem",
        }}
      >
        <Link href="/produtos" style={{ color: "var(--color-muted)", textDecoration: "none" }}>
          Produtos
        </Link>
        <span>/</span>
        <span style={{ color: "var(--color-text)" }}>{produto.nome}</span>
      </div>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "1rem", marginBottom: "2rem", flexWrap: "wrap" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "0.5rem" }}>
            <span className="ssr-tag"><span>⚡</span> SSR</span>
            {produto.categoria_nome && (
              <span className="badge">{produto.categoria_nome}</span>
            )}
          </div>
          <h1 style={{ margin: 0, fontSize: "2rem" }}>{produto.nome}</h1>
          <p
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "0.75rem",
              color: "var(--color-muted)",
              marginTop: "0.25rem",
            }}
          >
            ID #{produto.id}
          </p>
        </div>

        <div style={{ display: "flex", gap: "0.5rem" }}>
          <Link href={`/produtos/${produto.id}/editar`}>
            <button className="btn-ghost">✏️ Editar</button>
          </Link>
          <BotaoRemover id={produto.id} nome={produto.nome} />
        </div>
      </div>

      {/* Card principal */}
      <div className="card" style={{ padding: "2rem", marginBottom: "1.5rem" }}>
        {/* Preço e estoque */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "1.5rem",
            marginBottom: "1.75rem",
          }}
        >
          <div>
            <label>Preço</label>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "2rem",
                fontWeight: 700,
                color: "var(--color-brand-400)",
                marginTop: "0.25rem",
              }}
            >
              {produto.preco.toLocaleString("pt-BR", {
                style: "currency",
                currency: "BRL",
              })}
            </div>
          </div>
          <div>
            <label>Estoque</label>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "2rem",
                fontWeight: 700,
                color:
                  produto.estoque === 0
                    ? "#f87171"
                    : produto.estoque < 5
                    ? "#fbbf24"
                    : "var(--color-text)",
                marginTop: "0.25rem",
              }}
            >
              {produto.estoque}
              <span
                style={{
                  fontSize: "0.85rem",
                  color: "var(--color-muted)",
                  marginLeft: "0.4rem",
                  fontWeight: 400,
                }}
              >
                unidades
              </span>
            </div>
          </div>
        </div>

        {/* Descrição */}
        <div>
          <label>Descrição</label>
          <p
            style={{
              marginTop: "0.4rem",
              color: produto.descricao
                ? "var(--color-text)"
                : "var(--color-muted)",
              fontSize: "0.9rem",
              lineHeight: 1.6,
            }}
          >
            {produto.descricao || "Sem descrição cadastrada."}
          </p>
        </div>
      </div>

      {/* Metadados */}
      <div
        className="card"
        style={{
          padding: "1.25rem 1.5rem",
          display: "flex",
          gap: "2rem",
          flexWrap: "wrap",
        }}
      >
        {[
          ["Cadastrado em", produto.criado_em],
          ["Atualizado em", produto.atualizado_em],
        ].map(([label, valor]) => (
          <div key={label}>
            <label>{label}</label>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: "0.82rem",
                marginTop: "0.25rem",
                color: "var(--color-muted)",
              }}
            >
              {valor}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
