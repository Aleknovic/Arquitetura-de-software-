import Link from "next/link";
import { listarProdutos } from "@/lib/produtos";

// Esta página também usa SSR: os dados são obtidos no servidor
export default function Home() {
  const produtos = listarProdutos();
  const totalProdutos = produtos.length;
  const totalEstoque = produtos.reduce((s, p) => s + p.estoque, 0);
  const valorTotal = produtos.reduce((s, p) => s + p.preco * p.estoque, 0);

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: "2.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.75rem" }}>
          <span className="ssr-tag">
            <span>⚡</span> Server-Side Rendered
          </span>
        </div>
        <h1 style={{ fontSize: "2.5rem", margin: 0, lineHeight: 1.1 }}>
          Painel de Estoque
        </h1>
        <p style={{ color: "var(--color-muted)", marginTop: "0.5rem", fontSize: "1rem" }}>
          Gerencie seus produtos com persistência em SQLite
        </p>
      </div>

      {/* Cards de resumo */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "1rem", marginBottom: "3rem" }}>
        <StatCard
          label="Total de Produtos"
          value={totalProdutos.toString()}
          icon="📦"
          accent="var(--color-brand-500)"
        />
        <StatCard
          label="Unidades em Estoque"
          value={totalEstoque.toString()}
          icon="🏪"
          accent="#60a5fa"
        />
        <StatCard
          label="Valor Total"
          value={`R$ ${valorTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
          icon="💰"
          accent="#f59e0b"
        />
      </div>

      {/* Ações rápidas */}
      <div className="card" style={{ padding: "1.75rem", marginBottom: "2rem" }}>
        <h2 style={{ margin: "0 0 1.25rem", fontSize: "1.1rem" }}>Ações Rápidas</h2>
        <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
          <Link href="/produtos/novo">
            <button className="btn-primary">+ Cadastrar Produto</button>
          </Link>
          <Link href="/produtos">
            <button className="btn-ghost">📋 Ver Todos os Produtos</button>
          </Link>
        </div>
      </div>

      {/* Como funciona SSR */}
      <div className="card" style={{ padding: "1.75rem", borderColor: "var(--color-brand-700)" }}>
        <h2 style={{ margin: "0 0 1rem", fontSize: "1rem", color: "var(--color-brand-400)" }}>
          ⚡ Como o SSR funciona neste projeto
        </h2>
        <div style={{ display: "grid", gap: "0.75rem" }}>
          {[
            ["Server Component", "As páginas são React Server Components — o Next.js executa o código no servidor, acessa o SQLite e envia o HTML pronto ao navegador."],
            ["Sem useEffect", "Não há fetch do lado do cliente na listagem. Os dados chegam já no HTML inicial, melhorando performance e SEO."],
            ["Route Handlers", "As rotas /api/produtos/* são Route Handlers do App Router — permitem operações de escrita (POST, PUT, DELETE) via fetch do client."],
            ["SQLite local", "O banco de dados é um arquivo .db no servidor. Simples, zero configuração, ideal para projetos pequenos."],
          ].map(([titulo, descricao]) => (
            <div key={titulo} style={{ display: "flex", gap: "0.75rem" }}>
              <span style={{ color: "var(--color-brand-500)", flexShrink: 0, fontFamily: "var(--font-mono)", fontSize: "0.85rem" }}>▹</span>
              <div>
                <strong style={{ fontSize: "0.875rem", display: "block", marginBottom: "0.15rem" }}>{titulo}</strong>
                <span style={{ color: "var(--color-muted)", fontSize: "0.825rem" }}>{descricao}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon,
  accent,
}: {
  label: string;
  value: string;
  icon: string;
  accent: string;
}) {
  return (
    <div
      className="card"
      style={{ padding: "1.25rem 1.5rem", borderColor: "var(--color-border)" }}
    >
      <div style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>{icon}</div>
      <div
        style={{
          fontSize: "1.6rem",
          fontFamily: "var(--font-mono)",
          fontWeight: 700,
          color: accent,
          lineHeight: 1,
          marginBottom: "0.35rem",
        }}
      >
        {value}
      </div>
      <div style={{ fontSize: "0.78rem", color: "var(--color-muted)", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>
        {label}
      </div>
    </div>
  );
}
