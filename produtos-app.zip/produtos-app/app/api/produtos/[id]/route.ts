import { NextRequest, NextResponse } from "next/server";
import {
  buscarProduto,
  atualizarProduto,
  removerProduto,
} from "@/lib/produtos";
import type { ProdutoInput } from "@/types";

type Params = { params: Promise<{ id: string }> };

// GET /api/produtos/:id
export async function GET(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const produto = buscarProduto(Number(id));

  if (!produto) {
    return NextResponse.json(
      { erro: "Produto não encontrado" },
      { status: 404 }
    );
  }

  return NextResponse.json(produto);
}

// PUT /api/produtos/:id
export async function PUT(request: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await request.json() as Partial<ProdutoInput>;

    if (!body.nome || body.nome.trim() === "") {
      return NextResponse.json(
        { erro: "O campo 'nome' é obrigatório" },
        { status: 400 }
      );
    }
    if (body.preco === undefined || body.preco < 0) {
      return NextResponse.json(
        { erro: "O campo 'preco' é obrigatório e deve ser >= 0" },
        { status: 400 }
      );
    }

    const atualizado = atualizarProduto(Number(id), {
      nome: body.nome.trim(),
      descricao: body.descricao?.trim(),
      preco: Number(body.preco),
      estoque: Number(body.estoque ?? 0),
      categoria_id: body.categoria_id ?? null,
    });

    if (!atualizado) {
      return NextResponse.json(
        { erro: "Produto não encontrado" },
        { status: 404 }
      );
    }

    return NextResponse.json(atualizado);
  } catch (error) {
    console.error("[PUT /api/produtos/:id]", error);
    return NextResponse.json(
      { erro: "Erro ao atualizar produto" },
      { status: 500 }
    );
  }
}

// DELETE /api/produtos/:id
export async function DELETE(_req: NextRequest, { params }: Params) {
  const { id } = await params;
  const removido = removerProduto(Number(id));

  if (!removido) {
    return NextResponse.json(
      { erro: "Produto não encontrado" },
      { status: 404 }
    );
  }

  return NextResponse.json({ mensagem: "Produto removido com sucesso" });
}
