import { NextRequest, NextResponse } from "next/server";
import { listarProdutos, criarProduto } from "@/lib/produtos";
import type { ProdutoInput } from "@/types";

// GET /api/produtos — lista todos os produtos
export async function GET() {
  try {
    const produtos = listarProdutos();
    return NextResponse.json(produtos);
  } catch (error) {
    console.error("[GET /api/produtos]", error);
    return NextResponse.json(
      { erro: "Erro ao buscar produtos" },
      { status: 500 }
    );
  }
}

// POST /api/produtos — cria um novo produto
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as Partial<ProdutoInput>;

    // Validações básicas
    if (!body.nome || body.nome.trim() === "") {
      return NextResponse.json(
        { erro: "O campo 'nome' é obrigatório" },
        { status: 400 }
      );
    }
    if (body.preco === undefined || body.preco < 0) {
      return NextResponse.json(
        { erro: "O campo 'preco' é obrigatório e deve ser >= 0" },
        { status: 400 }
      );
    }
    if (body.estoque === undefined || body.estoque < 0) {
      return NextResponse.json(
        { erro: "O campo 'estoque' é obrigatório e deve ser >= 0" },
        { status: 400 }
      );
    }

    const novoProduto = criarProduto({
      nome: body.nome.trim(),
      descricao: body.descricao?.trim(),
      preco: Number(body.preco),
      estoque: Number(body.estoque),
      categoria_id: body.categoria_id ?? null,
    });

    return NextResponse.json(novoProduto, { status: 201 });
  } catch (error) {
    console.error("[POST /api/produtos]", error);
    return NextResponse.json(
      { erro: "Erro ao criar produto" },
      { status: 500 }
    );
  }
}
