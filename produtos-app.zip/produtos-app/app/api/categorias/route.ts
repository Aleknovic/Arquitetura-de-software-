import { NextResponse } from "next/server";
import { listarCategorias } from "@/lib/produtos";

export async function GET() {
  const categorias = listarCategorias();
  return NextResponse.json(categorias);
}
