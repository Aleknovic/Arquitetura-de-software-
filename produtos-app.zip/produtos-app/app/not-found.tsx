import Link from "next/link";

export default function NotFound() {
  return (
    <div
      style={{
        textAlign: "center",
        paddingTop: "5rem",
      }}
    >
      <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>📦</div>
      <h1 style={{ fontSize: "2rem", marginBottom: "0.5rem" }}>
        Produto não encontrado
      </h1>
      <p style={{ color: "var(--color-muted)", marginBottom: "2rem" }}>
        O produto que você procura não existe ou foi removido.
      </p>
      <Link href="/produtos">
        <button className="btn-primary">← Voltar para Produtos</button>
      </Link>
    </div>
  );
}
